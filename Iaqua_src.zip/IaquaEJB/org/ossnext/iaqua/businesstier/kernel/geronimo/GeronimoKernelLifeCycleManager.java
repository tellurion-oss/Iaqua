package org.ossnext.iaqua.businesstier.kernel.geronimo;

import org.apache.geronimo.gbean.AbstractName;
import org.apache.geronimo.gbean.GBeanData;
import org.apache.geronimo.kernel.GBeanAlreadyExistsException;
import org.apache.geronimo.kernel.GBeanNotFoundException;
import org.apache.geronimo.kernel.Kernel;
import org.apache.geronimo.kernel.NoSuchOperationException;
import org.apache.geronimo.kernel.basic.BasicKernelFactory;
import org.ossnext.iaqua.businesstier.kernel.common.BeanAlreadyExistsInKernelException;
import org.ossnext.iaqua.businesstier.kernel.common.BeanInvalidForKernelException;
import org.ossnext.iaqua.businesstier.kernel.common.BeanNotFoundInKernelException;
import org.ossnext.iaqua.businesstier.kernel.common.BeanOperationNotFoundException;
import org.ossnext.iaqua.businesstier.kernel.common.KernelLifeCycleManager;


/* GeronimoKernelLifeCycleManager.java
 * Created March 01 2012
 * 
 * Copyright (c) 2012,  Tellurion OSS Pvt. Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /*
  * @author admin@ossnext.org
  * 
  */
/**
 * Enter description here.
 *
 * @author <a href="mailto:admin@ossnext.org">OSSnext dot org</a>
 * @version : 2.3 $
 *          <p/>
 *          <p><b>Revisions:</b>
 *          <p/>
 *          <p><b>March 01, 2012 ossnext:</b>
 *          <ul>
 *          <li> Copyright (c) 2012 Tellurion OSS Pvt. Ltd. All Rights Reserved.
 *          </ul>
 */

public class GeronimoKernelLifeCycleManager extends KernelLifeCycleManager
{
	private Kernel iaquaAGKernel = null;
	
	private GeronimoKernelLifeCycleManager() throws Exception
	{
		this.iaquaAGKernel = BasicKernelFactory.newInstance().createKernel("IAquaAG");
		this.iaquaAGKernel.boot();
		log.debug("IAquaAG Kernel Booted at: " + iaquaAGKernel.getBootTime());
	}

	@Override
	public void rebootKernel() throws Exception
	{
		this.shutdownKernel();
		this.iaquaAGKernel = BasicKernelFactory.newInstance().createKernel("IAquaAG");
		this.iaquaAGKernel.boot();
		log.debug("IAquaAG Kernel Re-booted at: " + iaquaAGKernel.getBootTime());
	}

	@Override
	public void shutdownKernel() 
	{
		this.iaquaAGKernel.shutdown();
		log.debug("IAquaAG Kernel Shut down at: " + iaquaAGKernel.getBootTime());
	}
	
	private static KernelLifeCycleManager singletonManager = null;

	public static KernelLifeCycleManager getManager() throws Exception
	{
	   if (singletonManager == null)
	   {
	    singletonManager = new GeronimoKernelLifeCycleManager();
	   }

	   return singletonManager;
	}

	@ Override
	public void loadAndStartBeanInKernel(Object gBeanData, Object serviceName, ClassLoader classLoader) 
                                      throws BeanInvalidForKernelException,
                                             BeanNotFoundInKernelException,
                                             BeanAlreadyExistsInKernelException,
                                             UnsupportedOperationException
    {
      //gBeanData & serviceName need to be checked for compatibility against Geronimo app server.
      //if not compatible, throw exception and bail.
      //This is a humble attempt at avoiding too much tight coupling with Geronimo app srvr
      //and keeping our app somewhat portable across other app servers.
      if (gBeanData instanceof GBeanData && serviceName instanceof AbstractName)
      {
    	  try
    	  {
           iaquaAGKernel.loadGBean((GBeanData)gBeanData, classLoader);
           iaquaAGKernel.startGBean((AbstractName)serviceName);
    	  }
    	  catch(GBeanNotFoundException ex)
    	  {
    		  //log.debug("Exception while attempting to start GBean: " + gBeanData.toString() 
    			//	                                   + " problem: "  + ex.toString());
    		  throw new BeanNotFoundInKernelException("Exception while attempting to start GBean: " + gBeanData.toString() 
                      + " problem: "  + ex.toString());
    	  }
    	  catch(GBeanAlreadyExistsException ex)
    	  {
    		  //log.debug("Exception while attempting to load GBean: " + gBeanData.toString() 
               //                                        + " problem: "  + ex.toString());
    		  throw new BeanAlreadyExistsInKernelException("Exception while attempting to load GBean: " + gBeanData.toString() 
                      + " problem: "  + ex.toString());
    	  }
      }
      else
      {
        throw new BeanInvalidForKernelException();
      }
      
      log.debug("Loaded and started GBean in Kernel: " + ((AbstractName)serviceName).getObjectName());
    }
	
	@ Override
	public Object invokeOnBean(Object beanName, Object opName, 
            Object[] opParams, Object[] paramTypes) 
            throws IllegalArgumentException, 
                   BeanOperationNotFoundException,
                   Exception
	{	
		if (beanName instanceof AbstractName &&
			opName instanceof String) //TODO FIX THIS //&&
			//(paramTypes != null && paramTypes instanceof String[]))
		{
			try
			{
		    	  

		    	Object retObj = this.iaquaAGKernel.invoke((AbstractName)beanName, (String)opName, (Object[])opParams, (String[])paramTypes);
				
				
				//Deprecated version, but works
			  /*Object retObj = this.iaquaAGKernel.invoke((ObjectName)beanName, 
					                                   (String)opName, 
                                                       (Object[])opParams, 
                                                       (String[])paramTypes);*/
              return retObj;
			}
			catch (NoSuchOperationException ex)
			{
				throw new BeanOperationNotFoundException(ex.getMessage());
			}
			catch (GBeanNotFoundException ex)
			{
				throw new BeanNotFoundInKernelException(ex.getMessage());
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		else
		{
			throw new IllegalArgumentException();
		}
	}
	
	@ Override
	public boolean isBeanAlreadyInKernel(Object beanName)
    throws IllegalArgumentException,
    UnsupportedOperationException
    {
		boolean beanFound = false;
		
		if (beanName != null && beanName instanceof AbstractName)
		{
			try
			{
			  if (this.iaquaAGKernel.getGBean((AbstractName)beanName) != null)
			  {
				  beanFound = true;
			  }
			}
			catch(GBeanNotFoundException ex)
			{
			}
		}
		else
	    if (beanName == null)
		{
			throw new IllegalArgumentException("Null Bean Name passed");	
		}
		else
		{
			throw new IllegalArgumentException("Invalid Bean Type for Geronimo App Server.");
		}
		
		return beanFound;
    }
}
