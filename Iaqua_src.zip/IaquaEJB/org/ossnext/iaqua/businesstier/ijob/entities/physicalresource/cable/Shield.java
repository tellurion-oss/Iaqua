package org.ossnext.iaqua.businesstier.ijob.entities.physicalresource.cable;

import org.ossnext.iaqua.businesstier.ijob.entities.physicalresource.common.PhysicalResource;

/* Shield.java
* Created October 22 2012
* 
* Copyright (c) 2012,  Tellurion OSS Pvt. Ltd.
* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
*/

/*
 * @author admin@ossnext.org
 * 
 */

/**
*
* @author <a href="mailto:admin@ossnext.org">OSSnext dot org</a>
* @version : 2.3 $
*          <p/>
*          <p><b>Revisions:</b>
*          <p/>
*          <p><b>October 22, 2012 ossnext:</b>
*          <ul>
*          <li> Copyright (c) 2012 Tellurion OSS Pvt. Ltd. All Rights Reserved.
*          </ul>
*/

public class Shield extends PhysicalResource
{
    /* constituent parts*/
	
	/* attributes*/
	boolean isWireMesh;
	
	/* properties*/
	short metalType = MetalType.aluminiumType;
	
	class MetalType
	{
	     static final short copperType = 1;
	     static final short aluminiumType = 2;
	}
	
	public Shield(boolean isWireMesh, short metalType)
	{
		this.isWireMesh = isWireMesh;
		this.metalType = metalType;
	}
	
	@Override
	public void retrieveObject() 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setDSName(String dsName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getDSName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setName(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setAsTop() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isTop() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setConcreteTypeFQName(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getConcreteTypeFQName() {
		// TODO Auto-generated method stub
		return null;
	}

}
