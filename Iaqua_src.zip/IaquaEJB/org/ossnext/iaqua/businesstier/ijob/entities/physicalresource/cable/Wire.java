package org.ossnext.iaqua.businesstier.ijob.entities.physicalresource.cable;

/* Wire.java
* Created October 22 2012
* 
* Copyright (c) 2012,  Tellurion OSS Pvt. Ltd.
* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
*/

/*
 * @author admin@ossnext.org
 * 
 */

/**
*
* @author <a href="mailto:admin@ossnext.org">OSSnext dot org</a>
* @version : 2.3 $
*          <p/>
*          <p><b>Revisions:</b>
*          <p/>
*          <p><b>October 22, 2012 ossnext:</b>
*          <ul>
*          <li> Copyright (c) 2012 Tellurion OSS Pvt. Ltd. All Rights Reserved.
*          </ul>
*/

public class Wire 
{
	static final int strandMaterialTypeCopper = 1;
	static final int strandMaterialTypeGold = 2;
	static final int strandMaterialTypeAluminium = 3;
	
	static final int jacketTypePlastic = 4;
	static final int jacketTypeOther = 5;
	
	static final int jacketColorRed = 6;
	static final int jacketColorBlue = 7;
	static final int jacketColorGreen = 8;
	static final int jacketColorYellow = 9;
	static final int jacketColorBlack = 10;
	static final int jacketColorWhite = 11;
	
	static final int wireStrandTwelve = 12;
	static final int wireStrandSix = 13;
	
	static final int wireGauge14 = 14;
	static final int wireGauge16 = 15;
	
	static final int wireTypeCopper = 16;
	static final int wireTypeAluminium = 17;
	
	int wireType;
	int jacketType;
	int wireStrandType;
	int wireGaugeType;
	
	int wireID;
	
	public Wire(int wireID, int wireType, int jacketType, int wireStrandType, int wireGaugeType)
	{
		this.wireID = wireID;
		this.wireType = wireType;
		this.wireStrandType = wireStrandType;
		this.wireGaugeType = wireGaugeType;
		this.jacketType = jacketType;
	}
}
