/**
 * 
 */
package org.ossnext.iaqua.businesstier.ijob.entities.physicalresource.cable;

import org.ossnext.iaqua.apptier.RemoteBusinessInterface;
import org.ossnext.iaqua.businesstier.ijob.entities.physicalresource.common.PhysicalResource;


/* Sheath.java
 * Created October 22 2012
 * 
 * Copyright (c) 2012,  Tellurion OSS Pvt. Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /*
  * @author admin@ossnext.org
  * 
  */

/**
*
* @author <a href="mailto:admin@ossnext.org">OSSnext dot org</a>
* @version : 2.3 $
*          <p/>
*          <p><b>Revisions:</b>
*          <p/>
*          <p><b>October 22, 2012 ossnext:</b>
*          <ul>
*          <li> Copyright (c) 2012 Tellurion OSS Pvt. Ltd. All Rights Reserved.
*          </ul>
*/

public class Sheath extends PhysicalResource 
{

	/* (non-Javadoc)
	 * @see org.ossnext.iaqua.apptier.RemoteBusinessInterface#writeOutput(java.lang.String)
	 */
	
	int sheathID;
	
	/* constituent parts*/
	Shield shield;
	
	/* attributes*/
	int insulatorType;
	
	/* properties*/
	int permeabilityType;
	int color;
	
	class InsulatorType
	{
	     static final int paperType = 1;
	     static final int jellyType = 2;
	}
	
	class PermeabilityType
	{
		static final int semiPermeable = 1;
		static final int nonPermeable =2;
		static final int permeable = 3;
	}
	
	class Color
	{
		static final int white = 1;
		static final int blue = 2;
		static final int red = 3;
	}
	
	public Sheath(int sheathID, int insulatorType, int permeability, int color, Shield shield)
	{
		this.sheathID = sheathID;
		this.insulatorType = insulatorType;
		this.permeabilityType = permeability;
		this.color = color;
		this.shield = shield;
	}

	@Override
	public void retrieveObject() 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setDSName(String dsName) 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getDSName() 
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setName(String name) 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getName() 
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setAsTop() 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isTop() 
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setConcreteTypeFQName(String name) 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getConcreteTypeFQName() 
	{
		// TODO Auto-generated method stub
		return null;
	}

}
