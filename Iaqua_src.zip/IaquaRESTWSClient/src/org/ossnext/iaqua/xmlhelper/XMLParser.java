package org.ossnext.iaqua.xmlhelper;

import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.TypeInfoProvider;
import javax.xml.validation.ValidatorHandler;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
* 
* http://www.apache.org/licenses/LICENSE-2.0
* 
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/*
 * @author admin@ossnext.org
 * 
 */

/**
* Enter description here.
*
* @author <a href="mailto:admin@ossnext.org">OSSnext dot org</a>
* @version : 2.3 $
*          <p/>
*          <p><b>Revisions:</b>
*          <p/>
*          <p><b>December 09, 2012 ossnext:</b>
*          <ul>
*          <li> Copyright (c) 2012 Tellurion OSS Pvt. Ltd. All Rights Reserved.
*          </ul>
*/

/* This class will obtain the Iaqua data types from xml and maintain them in a hash table */
/* Data types are either "standard" or "abstract" */
public class XMLParser extends DefaultHandler 
{
    private TypeInfoProvider provider;
    //private static Hashtable<String, Vector<String>> tableOfNodeNames = new Hashtable<String, Vector<String>>();
    public static Hashtable<String, String> tableOfNodeNames = new Hashtable<String, String>();
    
    private XMLParser(TypeInfoProvider provider) 
    {
        this.provider = provider;
    }

    public static void doProcess() throws SAXException, IOException 
    {
        SchemaFactory factory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
        //File schemaLocation = new File("C://Users/jonmejoy/Downloads/Iaqua-development/iaqua.xsd");
        File schemaLocation = new File("C://Users/jonmejoy/Downloads/Iaqua-development/iaqua_typeclassifier.xsd");
        
        if (schemaLocation.exists())
        {	
        	/****************First, get the Node Names *********************/
            /*                                                             */
        	
        	Schema schema = factory.newSchema(schemaLocation);
            
            ValidatorHandler vHandler = schema.newValidatorHandler();
            TypeInfoProvider provider = vHandler.getTypeInfoProvider();
            ContentHandler   cHandler = new XMLParser(provider);
            vHandler.setContentHandler(cHandler);
            
            XMLReader parser = XMLReaderFactory.createXMLReader();
            parser.setContentHandler(vHandler);
            //parser.parse("C://Users/jonmejoy/Downloads/Iaqua-development/iaqua.xml");
            parser.parse("C://Users/jonmejoy/Downloads/Iaqua-development/iaqua_classifiedtypes.xml");
            
            /****************Now get the values ****************************/
            /*                                                             */
            try
            {
            	 DocumentBuilderFactory factory2 = DocumentBuilderFactory.newInstance();
                 DocumentBuilder builder = factory2.newDocumentBuilder();
                 Document doc = builder.parse("C://Users/jonmejoy/Downloads/Iaqua-development/iaqua_classifiedtypes.xml");
                 doc.getDocumentElement().normalize();
                 System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
                 
                 //insert all "standard" values to the hashtable against "standard" key
                 for (int i = 0; i < doc.getElementsByTagName("standard").getLength(); i++) 
                 {
                     NodeList nList = doc.getElementsByTagName("standard").item(i).getChildNodes();
             		 System.out.println("-----------------------");
             		
             		 Node nValue = (Node) nList.item(0);
            		 System.out.println("nValue.getNodeValue(): " + nValue.getNodeValue());
            		 
            		 /*if (XMLParser.getNodeNamesTable().containsKey("standard"))
            		 {
            			 ((XMLParser)cHandler).insertIntoNodeNameTable("standard", nValue.getNodeValue());
            		 }*/
            		 
            		 if (!XMLParser.getNodeNamesTable().containsKey(nValue.getNodeValue()))
            		 {
            			 ((XMLParser)cHandler).insertIntoNodeNameTable(nValue.getNodeValue(), "standard");
            		 }
                 }
                 
                 //insert all "abstract" values to the hashtable against "abstract" key
                 for (int i = 0; i < doc.getElementsByTagName("abstract").getLength(); i++) 
                 {
                     NodeList nList = doc.getElementsByTagName("abstract").item(i).getChildNodes();
             		 System.out.println("-----------------------");
             		
             		 Node nValue = (Node) nList.item(0);
            		 System.out.println("nValue.getNodeValue(): " + nValue.getNodeValue());
            		 
            		 /*if (XMLParser.getNodeNamesTable().containsKey("abstract"))
            		 {
            			 ((XMLParser)cHandler).insertIntoNodeNameTable("abstract", nValue.getNodeValue());
            		 }*/
            		 
            		 if (!XMLParser.getNodeNamesTable().containsKey(nValue.getNodeValue()))
            		 {
            			 ((XMLParser)cHandler).insertIntoNodeNameTable(nValue.getNodeValue(), "abstract");
            		 }
                 }
                 
                 //Iterator<Map.Entry<String, Vector<String>>> it = XMLParser.getNodeNamesTable().entrySet().iterator();
                 Iterator<Map.Entry<String, String>> it = XMLParser.getNodeNamesTable().entrySet().iterator();
         	     System.out.println(">>>>>> >>>>>> >>>>>>> >>>>>>> Hashtable contents>> ");
         	    
         	     while(it.hasNext())
         	     {
         	    	Map.Entry<String, String> entry = it.next();
         	    	
         	    	if (entry.getKey() != null) 
         	    	{
         	          System.out.print("\r\n>> Key: " + entry.getKey() + "\r\n");
         	          System.out.print("\r\n>> Value: " + entry.getValue() + "\r\n");
         	        
         	          /*for(int p = 0; p < entry.getValue().size(); p++)
         	          {
         	        	  System.out.print(entry.getValue().get(p) + ", ");
         	          }*/
         	    	}
         	     }
            }
            catch (Exception e)
            {
              System.err.println(e);
            }  
        }
        else
        {
          System.out.println("XML File to parse not found!");
        }
    }
    
    private void insertIntoNodeNameTable(String value, String qualifiedName)
    {
    	/*Vector<String> values = XMLParser.tableOfNodeNames.get(qualifiedName);
    	values.add(value);
    	XMLParser.tableOfNodeNames.put(qualifiedName, values);*/
    	
    	XMLParser.tableOfNodeNames.put(value, qualifiedName);
	}

	public void startElement(String namespace, String localName, String qualifiedName, Attributes atts) throws SAXException 
    {
        String type = provider.getElementTypeInfo().getTypeName();
        System.out.println(qualifiedName + ": " + type);
        //System.out.println(atts.getIndex("", localName));
        
        //create keys
        /*if ((type.compareToIgnoreCase("iaquatypeclassifier") == 0) && !XMLParser.tableOfNodeNames.containsKey(qualifiedName))
        {
        	XMLParser.tableOfNodeNames.put(qualifiedName, new Vector<String>());
        }*/
    }

    //public static Hashtable<String, Vector<String>> getNodeNamesTable()
	public static Hashtable<String, String> getNodeNamesTable()
    {
    	return XMLParser.tableOfNodeNames;
    }
}
