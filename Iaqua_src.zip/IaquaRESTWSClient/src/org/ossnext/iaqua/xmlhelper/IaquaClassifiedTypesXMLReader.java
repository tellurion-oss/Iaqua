package org.ossnext.iaqua.xmlhelper;


import java.io.File;
//import java.util.Calendar;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/* IaquaClassifiedTypesXMLReader.java
 * Created October 31 2012
 * 
 * Copyright (c) 2012, Tellurion OSS Pvt. Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /*
  * @author admin@ossnext.org
  * 
  */

/**
 * Enter description here.
 *
 * @author <a href="mailto:admin@ossnext.org">OSSnext dot org</a>
 * @version : 2.3 $
 *          <p/>
 *          <p><b>Revisions:</b>
 *          <p/>
 *          <p><b>December 09, 2012 ossnext:</b>
 *          <ul>
 *          <li> Copyright (c) 2012 Tellurion OSS Pvt. Ltd. All Rights Reserved.
 *          </ul>
 */

public class IaquaClassifiedTypesXMLReader 
{
	//static Vector<Vector<String>> vectorOfNodeNameVectors = new Vector<Vector<String>>();
	static Hashtable<Integer, Vector<String>> tableOfNodeNames = new Hashtable<Integer, Vector<String>>();
	
 public static void main(String args[]) 
 {
  StringTokenizer strToken1 = null;
  
  try 
  {   
   File file = new File("C://Users/jonmejoy/Downloads/Iaqua-development/iaqua_classifiedtypes.xml");
   DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
   DocumentBuilder db = dbf.newDocumentBuilder();
   Document doc = db.parse(file);
   doc.getDocumentElement().normalize();
   //retain sysout
   //System.out.println("parsed iaqua xml Information");
   //retain sysout
   System.out.println("Root element: " + doc.getDocumentElement().getNodeName());
   
   NodeList nodeLst = doc.getElementsByTagName("iaquatype");
   System.out.println("nodeLst.getLength(): " + nodeLst.getLength());
   
    for (int s = 0; s < nodeLst.getLength(); s++) 
    {    	   	
	    Node node = nodeLst.item(s);
	    //retain sysout
	    System.out.println("**********************************************Processing Node Type: " + node.getNodeName());
    	
	    NamedNodeMap nnMap = node.getAttributes();
	    
	    if (nnMap != null)
		{
	    	System.out.println("nnMap.getLength(): " + nnMap.getLength());
	    	/*strToken1 = new StringTokenizer(nnMap.item(0).toString(), new String("="));
		  	strToken1.nextToken();
		  	if(strToken1.hasMoreTokens() == true)
            {
			    strToken1.nextToken().trim().replaceAll("^\"|\"$", "");
            } */
	    	
	    	for (int i = 0; i < nnMap.getLength(); i++)
	    	{
	    		if (nnMap.item(i).getNodeName().compareToIgnoreCase("versionid") == 0)
	    		{
	    			System.out.println("!!>>!!>>!!>> Version is: " + nnMap.item(i).getNodeValue());
	    		}
	    	}   
		}
	    
	    NodeList mainNodeChildrenNodeList = node.getChildNodes();
	        
	    IaquaClassifiedTypesXMLReader.crunchNodes(mainNodeChildrenNodeList, 1);
	   
	    Iterator<Map.Entry<Integer, Vector<String>>> it = IaquaClassifiedTypesXMLReader.tableOfNodeNames.entrySet().iterator();
	    System.out.println(">>>>>> >>>>>> >>>>>>> >>>>>>> Hashtable contents>> ");
	    
	    while(it.hasNext())
	    {
	    	Map.Entry<Integer, Vector<String>> entry = it.next();
	    	
	    	if (entry.getKey() != null && entry.getKey() >= 0) 
	    	{
	          System.out.print(entry.getKey() + " : ");
	        
	          for(int p = 0; p < entry.getValue().size(); p++)
	          {
	        	  System.out.print(entry.getValue().get(p) + " : ");
	          }
	    	}
	    }
	    System.out.println(" end.");
	    
	    Element elementToDetect = (Element) node;
	    NodeList internalsNodeList = elementToDetect.getElementsByTagName("standard");
	    
	    if (internalsNodeList != null)
	    {	
	    	
	//////////
	    	System.out.println("internalsNodeList.getLength() " + internalsNodeList.getLength());
	           
	           for (int tIndex = 0; tIndex < internalsNodeList.getLength(); tIndex++)
	           {
	        	   Element tElem = (Element)internalsNodeList.item(tIndex);
	        	   NodeList tSPActNodelist = tElem.getElementsByTagName("standard");
	        	   
	        	   NamedNodeMap tSNNM = tSPActNodelist.item(0).getAttributes();
	        	   
	        	   if (tSNNM != null)
        		   {
 		    			  
		        	   for (int y = 0; y < tSNNM.getLength(); y++)
 		  	    	   {
		        		 System.out.println("!>!>!> tSNNM.item(y).toString() : "  + tSNNM.item(y).toString());
 		  	    	     strToken1 = new StringTokenizer(tSNNM.item(y).toString(), new String("="));
 				  	     strToken1.nextToken();
 				  	     
 				  	   if (tSNNM.item(y).toString().startsWith("name="))
 		  	    		 {
 		  	    		    if(strToken1.hasMoreTokens() == true)
 		  	                {
 		  	    			  strToken1.nextToken().trim().replaceAll("^\"|\"$", "");
 		  	                }
 		  	    		 }
 		  	    		 else
 		  	    	     if (tSNNM.item(y).toString().startsWith("color="))
 			  	    	 {
 		  	    	    	if(strToken1.hasMoreTokens() == true)
 		  	                {
 		  	    			  strToken1.nextToken().trim().replaceAll("^\"|\"$", "");
 		  	                }
 			  	    	 }
 		  	    	     else
 			  	    	 if (tSNNM.item(y).toString().startsWith("timegiven="))
 				  	     {
 			  	    	    if(strToken1.hasMoreTokens() == true)
 			  	            {
 			  	    		  Long.parseLong(strToken1.nextToken().trim().replaceAll("^\"|\"$", ""));
 			  	            }
 				  	     }
 			  	    	else
 				  	    if (tSNNM.item(y).toString().startsWith("timetaken="))
 					  	{
 				  	    	if(strToken1.hasMoreTokens() == true)
 				  	        {
 				  	    	  Long.parseLong(strToken1.nextToken().trim().replaceAll("^\"|\"$", ""));
 				  	        }
 					  	 }
 				  	     else
					  	 if (tSNNM.item(y).toString().startsWith("commenced="))
						 {
					  		if(strToken1.hasMoreTokens() == true)
				  	        {
					  		   String timeStr = strToken1.nextToken().trim().replaceAll("^\"|\"$", "");
					  		   StringTokenizer tmToken = new StringTokenizer(timeStr, new String("."));
				  	        }
						  }
 		  	    	     else
 		  	    	     {
 				  	       if (tSNNM.item(y).toString().compareToIgnoreCase("istimed=\"true\"") == 0)
 					       {
 					       }
 				  	       else
 				  	       {
 				  	       }
 		  	    	     }
 				  	   
 		  	    		 //System.out.println("subpillar activity Attribs: " + nnmap2.item(y).toString());
 		  	    	   }
 		  	    	    
		        	   //retain sysout	
 		  	    	   //System.out.println("Object filled is " + subPillarActivityNode.toString());
 				       //acts.activitiesUnderThisSubPillar.add(subPillarActivityNode);
 		    		  
        		   }
		           
	           }
	           
	           ////////////////
	    	
	    	
	      Element subPillarNodeListElement = (Element)internalsNodeList.item(0);
	      if (subPillarNodeListElement != null)
	      {
	    	  //System.out.println("going to test if subpillar is found " + subPillarNodeListElement.toString());
		      NodeList childrenNodes = subPillarNodeListElement.getChildNodes();
		      if (childrenNodes != null)
		      {
		        for (int j = 0; j < childrenNodes.getLength(); j++)
		        {
		         if (((Node) childrenNodes.item(j)).getNodeValue() != null)
		         {
		           //subPillarFound = true;
		           //System.out.println("!!>>!!>>!!>>subpillar node name : "  + ((Node) childrenNodes.item(j)).getNodeValue());
		        
			       continue;
		         }
		        }
		      }
		      else
		      {

		      }
	      }
	    }//ODC
	    else
	    {

		}
	    
	    if (node.getNodeType() == Node.ELEMENT_NODE) 
	    {	
		    
	    	NamedNodeMap pNNM = node.getAttributes();
	    	
	    	/*if (pNNM != null)
    		{
	    		for (int p = 0; p < pNNM.getLength(); p++)
  	    	    {
	    			System.out.println("pillar Node Attribs: " + pNNM.item(p).toString());
  	    	    }
    		}*/
	    	
	      NodeList elemList = null;
	      Element element = (Element) node;
	      elemList = element.getElementsByTagName("material");
	      
	      if (elemList != null)
	      {
	    	  for (int x = 0; x < elemList.getLength(); x++)
	    	  {
	    		  Element pillarElement = (Element) elemList.item(x);
	    		  
		    	  if (pillarElement == null)
		    	  {
		    		  //System.out.println("screeeech");
		    	  }
		    	  else
		    	  {
		    		  NodeList pillarActivityList = pillarElement.getChildNodes();
		    		  
		    		  NamedNodeMap nnmap2 = pillarElement.getAttributes();
		    		  if (nnmap2 != null)
		    		  {
		    			//pillarActivityNode = new toedatamodel.TOEPillarActivityNode();
		    			  
		  	    	    for (int y = 0; y < nnmap2.getLength(); y++)
		  	    	    {
		  	    	     //retain sysout
		  	    		 //System.out.println("pillar activity Attribs: " + nnmap2.item(y).toString());
		  	    		 
		  	    		 strToken1 = new StringTokenizer(nnmap2.item(y).toString(), new String("="));
		  	    		 strToken1.nextToken();
		  	    		 
		  	    		 if (nnmap2.item(y).toString().startsWith("name="))
		  	    		 {
		  	    		    if(strToken1.hasMoreTokens() == true)
		  	                {
		  	    		    	strToken1.nextToken().trim().replaceAll("^\"|\"$", "");
		  	                }
		  	    		 }
		  	    		 else
		  	    	     if (nnmap2.item(y).toString().startsWith("color="))
			  	    	 {
		  	    	    	if(strToken1.hasMoreTokens() == true)
		  	                {
		  	    			  strToken1.nextToken().trim().replaceAll("^\"|\"$", "");
		  	                }
			  	    	 }
		  	    	     else
			  	    	 if (nnmap2.item(y).toString().startsWith("timegiven="))
				  	     {
			  	    	    if(strToken1.hasMoreTokens() == true)
			  	            {
			  	    		  Long.parseLong(strToken1.nextToken().trim().replaceAll("^\"|\"$", ""));
			  	            }
				  	     }
			  	    	else
				  	    if (nnmap2.item(y).toString().startsWith("timetaken="))
					  	{
				  	    	if(strToken1.hasMoreTokens() == true)
				  	        {
				  	    	  Long.parseLong(strToken1.nextToken().trim().replaceAll("^\"|\"$", ""));
				  	        }
					  	 }
				  	     else
					  	 if (nnmap2.item(y).toString().startsWith("commenced="))
						 {
					  		if(strToken1.hasMoreTokens() == true)
				  	        {
					  		   String timeStr = strToken1.nextToken().trim().replaceAll("^\"|\"$", "");
					  		   StringTokenizer tmToken = new StringTokenizer(timeStr, new String("."));
					  		   /*pillarActivityNode.timingCommenced = Calendar.getInstance();
					  		   pillarActivityNode.timingCommenced.set(Calendar.HOUR_OF_DAY, Integer.parseInt(tmToken.nextToken()));
					  	       if(tmToken.hasMoreTokens() == true)
					  	       {
					  	         pillarActivityNode.timingCommenced.set(Calendar.MINUTE, Integer.parseInt(tmToken.nextToken()));
					  	       }
					  		   if(tmToken.hasMoreTokens() == true)
					  	       {
					  	         pillarActivityNode.timingCommenced.set(Calendar.SECOND, Integer.parseInt(tmToken.nextToken()));
					  	       }*/
				  	        }
						  }
		  	    	     else
		  	    	     {
				  	       if (nnmap2.item(y).toString().compareToIgnoreCase("istimed=\"true\"") == 0)
					       {
					  	    //pillarActivityNode.isTimed = true;
					       }
				  	       else
				  	       {
				  	    	 //pillarActivityNode.isTimed = false;
				  	       }
		  	    	     }
		  	    	   }
		  	    	    
		  	    	   if (pNNM != null)
		  	    	   {
		  	    		 strToken1 = new StringTokenizer(pNNM.item(0).toString(), new String("="));
				  	     strToken1.nextToken();
		  	    		 if (pNNM.item(0).toString().startsWith("name="))
		  	    		 {
		  	    		    if(strToken1.hasMoreTokens() == true)
		  	                {
				  	    		 strToken1.nextToken().trim().replaceAll("^\"|\"$", "");
		  	                }
		  	    		 }
			  	    	 //toe.activitiesUnderThisPillar.add(pillarActivityNode);
			  	    	 //System.out.println("Object filled is " + toe.toString());
		  	    	   }
		    		  }
		    		  else
		    		  {
		    			  //System.out.println("nnmap2 is null");
		    		  }
		    		  
				      //System.out.println("Activity Name : "  + ((Node) pillarNodeList.item(0)).getNodeValue());
				      for (int j = 0; j < pillarActivityList.getLength(); j++)
				      {
				        //System.out.println("pillar Name: " + nnMap.item(0).toString() + ", Activity Name : "  + ((Node) pillarActivityList.item(j)).getNodeValue());
				      } 
				      /*NodeList lstNmElmntLst = element.getElementsByTagName("lastname");
				      Element lstNmElmnt = (Element) lstNmElmntLst.item(0);
				      NodeList lstNm = lstNmElmnt.getChildNodes();
				      System.out.println("Last Name : " + ((Node) lstNm.item(0)).getNodeValue());*/  
		    	  }
	    	  }
	      }
	      else
	      {
	    	  //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ No activity found");
	      }
	      
	    }
	    else
	    {
	    }
	  }
  } 
  catch (Exception e) 
  {
    e.printStackTrace();
  }
  
  //All's well. Indicate parsing success
  //SchemaManager.parsingErrored = false;
  //schemaManager.setParsingErrorred(false);
  return;
}
 
private static int crunchNodes(NodeList nodeList, int iterLevel)//, Vector<String> passedNodeNames)
{
	if (nodeList == null)
	{
		return --iterLevel;
	}
	
	Vector<String> nodeNames = new Vector<String>();
	
    for (int i = 0; i < nodeList.getLength(); i++) 
    {
    	Node chldNode = nodeList.item(i);
    	if (chldNode.getNodeType() == 1)
    	{
    		System.out.println("Iter Level: " + iterLevel + ", !!>>!!>>!!>> Child Node is: " + chldNode.getNodeType() + ":" + chldNode.getNodeName() + ":" + chldNode.toString());
    		//passedNodeNames.add(iterLevel + " : " + chldNode.getNodeName());
    		
    		if (IaquaClassifiedTypesXMLReader.tableOfNodeNames.containsKey(iterLevel))
    		{
    			Vector<String> existingNodeNames;
    			existingNodeNames = IaquaClassifiedTypesXMLReader.tableOfNodeNames.get(iterLevel);
    			existingNodeNames.add(chldNode.getNodeName());
    			IaquaClassifiedTypesXMLReader.tableOfNodeNames.put(iterLevel, existingNodeNames);
    		}
    		else
    		{
        		nodeNames.add(chldNode.getNodeName());
        		IaquaClassifiedTypesXMLReader.tableOfNodeNames.put(iterLevel, nodeNames);
    		}
    		
    		NodeList childrenNodeList = chldNode.getChildNodes();
    		
    		//Every time iter level is incremented, instantiate a new vector of node element names for the new iter level
    		//Vector<String> nodeNames = new Vector<String>();
    		iterLevel = IaquaClassifiedTypesXMLReader.crunchNodes(childrenNodeList, ++iterLevel);//, nodeNames);
    		//iterLevel=-1;
    	}
    	//NamedNodeMap nnmap2 = chldNode.getAttributes();
    }
    
    /*if(passedNodeNames.size() > 0)
    {
	  IaquaXMLReader.vectorOfNodeNameVectors.add(passedNodeNames);
    }*/
    
    return --iterLevel;
}
 
private IaquaClassifiedTypesXMLReader()
{
}
}