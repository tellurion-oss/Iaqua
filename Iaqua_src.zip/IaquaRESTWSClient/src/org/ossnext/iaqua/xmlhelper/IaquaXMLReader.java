package org.ossnext.iaqua.xmlhelper;


import java.io.File;
import java.io.IOException;
//import java.util.Calendar;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.TypeInfoProvider;
import javax.xml.validation.ValidatorHandler;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

/* IAquaXMLReader.java
 * Created October 31 2012
 * 
 * Copyright (c) 2012, Tellurion OSS Pvt. Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /*
  * @author admin@ossnext.org
  * 
  */

/**
 * Enter description here.
 *
 * @author <a href="mailto:admin@ossnext.org">OSSnext dot org</a>
 * @version : 2.3 $
 *          <p/>
 *          <p><b>Revisions:</b>
 *          <p/>
 *          <p><b>December 09, 2012 ossnext:</b>
 *          <ul>
 *          <li> Copyright (c) 2012 Tellurion OSS Pvt. Ltd. All Rights Reserved.
 *          </ul>
 */

public class IaquaXMLReader 
{
	//static Vector<Vector<String>> vectorOfNodeNameVectors = new Vector<Vector<String>>();
	//static Hashtable<Integer, Vector<String>> tableOfNodeNames = new Hashtable<Integer, Vector<String>>();
	public static Vector<String> nodesInHierarchy = new Vector<String>();
	public static Hashtable<String, MethodSignature> tableOfMethodSignatures = new Hashtable<String, MethodSignature>();
	
 public static void doProcess(String args[]) 
 {
  try 
  { 
	 //First, load all Iaqua data types. This will help map data types to entity's constituent parts, attributes, properties  
	 XMLParser.doProcess();
	   
	 //Now, process XML for the Iaqua entity
     File file = new File("C://Users/jonmejoy/Downloads/Iaqua-development/iaqua.xml");
   
     if (file.exists())
     {   
	   DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	   DocumentBuilder db = dbf.newDocumentBuilder();
	   Document doc = db.parse(file);
	   doc.getDocumentElement().normalize();
	   //retain sysout
	   //System.out.println("parsed iaqua xml Information");
	   //retain sysout
	   System.out.println("Root element: " + doc.getDocumentElement().getNodeName());
	   
	   NodeList nodeLst = doc.getElementsByTagName("cable");
	   System.out.println("nodeLst.getLength(): " + nodeLst.getLength());
	   
	    for (int s = 0; s < nodeLst.getLength(); s++) 
	    {    	   	
		    Node node = nodeLst.item(s);
		    //retain sysout
		    System.out.println("**********************************************Processing Node Type: " + node.getNodeName());
	    	
		    NamedNodeMap nnMap = node.getAttributes();
		    
		    if (nnMap != null)
			{
		    	System.out.println("nnMap.getLength(): " + nnMap.getLength());
		    	/*strToken1 = new StringTokenizer(nnMap.item(0).toString(), new String("="));
			  	strToken1.nextToken();
			  	if(strToken1.hasMoreTokens() == true)
	            {
				    strToken1.nextToken().trim().replaceAll("^\"|\"$", "");
	            } */
		    	
		    	for (int i = 0; i < nnMap.getLength(); i++)
		    	{
		    		System.out.println("(nnMap.item(i).getNodeName(): " + nnMap.item(i).getNodeName());
		    		if (nnMap.item(i).getNodeName().compareToIgnoreCase("cableid") == 0)
		    		{
		    			System.out.println("!!>>!!>>!!>> Cable id is: " + nnMap.item(i).getNodeValue());
		    		}
		    	}   
			}
		    
		    NodeList cableChildrenNodeList = node.getChildNodes();
		    
		    IaquaXMLReader.crunchNodes(db, doc, cableChildrenNodeList, 1);//, new Vector<String>());
		    
		    //Iterator<Map.Entry<Integer, Vector<String>>> it = IaquaXMLReader.tableOfNodeNames.entrySet().iterator();
		    //System.out.println(">>>>>> >>>>>> >>>>>>> >>>>>>> Hashtable contents>> ");
		    System.out.println(">>>>>> >>>>>> >>>>>>> >>>>>>> Vector contents>> ");
		    
		    for (int i = 0; i < IaquaXMLReader.nodesInHierarchy.size(); i++)
		    {
		    	System.out.print(IaquaXMLReader.nodesInHierarchy.elementAt(i) + " | ");
		    }
		    
		    /*while(it.hasNext())
		    {
		    	Map.Entry<Integer, Vector<String>> entry = it.next();
		    	
		    	if (entry.getKey() != null && entry.getKey() >= 0) 
		    	{
		          System.out.print(entry.getKey() + " : ");
		        
		          for(int p = 0; p < entry.getValue().size(); p++)
		          {
		        	  System.out.print(entry.getValue().get(p) + " : ");
		          }
		    	}
		    }*/
		    
		    System.out.println("\r\nend.");
		  }
	    
	      //All seems to be well so far; now load methods from method xml
	      IaquaXMLReader.processMethodsFromXML();
   }
  } 
  catch (Exception e) 
  {
    e.printStackTrace();
  }
  
  //All's well. Indicate parsing success
  //SchemaManager.parsingErrored = false;
  //schemaManager.setParsingErrorred(false);
  return;
}
 
private static int crunchNodes(DocumentBuilder db, Document doc, NodeList nodeList, int iterLevel)//, Vector<String> passedNodeNames)
{
	if (nodeList == null)
	{
		return --iterLevel;
	}
	
	//Vector<String> nodeNames = new Vector<String>();
	
    for (int i = 0; i < nodeList.getLength(); i++) 
    {
    	Node chldNode = nodeList.item(i);
    	if (chldNode.getNodeType() == 1)
    	{
    		System.out.println("Iter Level: " + iterLevel + ", !!>>!!>>!!>> Child Node is: " + chldNode.getNodeType() + ":" + chldNode.getNodeName());    	
    		IaquaXMLReader.nodesInHierarchy.add(iterLevel + "," + chldNode.getNodeName() + "," + XMLParser.getNodeNamesTable().get(chldNode.getNodeName()));
    		//passedNodeNames.add(iterLevel + " : " + chldNode.getNodeName());
    		
    		/*if (IaquaXMLReader.tableOfNodeNames.containsKey(iterLevel))
    		{
    			Vector<String> existingNodeNames;
    			existingNodeNames = IaquaXMLReader.tableOfNodeNames.get(iterLevel);
    			existingNodeNames.add(chldNode.getNodeName());
    			
    			//Hashtable<String, Vector<String>> table = XMLParser.getNodeNamesTable();
    			Hashtable<String, String> table = XMLParser.getNodeNamesTable();
    			//Vector<String> stdDataTypes = table.get("standard");
    			
    			//if (chldNode.getNodeName().compareToIgnoreCase("strandmaterial") == 0)
    			if (table.containsKey(chldNode.getNodeName()))
    			{
    				try
    				{
    				  NodeList nList = doc.getElementsByTagName(chldNode.getNodeName()).item(0).getChildNodes();
    				  Node nValue = (Node) nList.item(0);
    				  System.out.println("For node name " + chldNode.getNodeName() + ", Value idhaar: " + nValue.getNodeValue());
    				}
    				catch (Exception e)
    	            {
    	              System.err.println(e);
    	            }
    			}
    			
    			IaquaXMLReader.tableOfNodeNames.put(iterLevel, existingNodeNames);
    		}
    		else
    		{
        		nodeNames.add(chldNode.getNodeName());
        		IaquaXMLReader.tableOfNodeNames.put(iterLevel, nodeNames);
    		}*/
    		
    		NodeList childrenNodeList = chldNode.getChildNodes();
    		
    		//Every time iter level is incremented, instantiate a new vector of node element names for the new iter level
    		//Vector<String> nodeNames = new Vector<String>();
    		iterLevel = IaquaXMLReader.crunchNodes(db, doc, childrenNodeList, ++iterLevel);//, nodeNames);
    		//iterLevel=-1;
    	}
    	//NamedNodeMap nnmap2 = chldNode.getAttributes();
    }
    
    /*if(passedNodeNames.size() > 0)
    {
	  IaquaXMLReader.vectorOfNodeNameVectors.add(passedNodeNames);
    }*/
    
    return --iterLevel;
 }

 public static int crunchMethodNodes(Document doc, NodeList nodeList, int iterLevel)
 {

		if (nodeList == null)
		{
			return --iterLevel;
		}
		
		//Vector<String> nodeNames = new Vector<String>();
		
	    for (int i = 0; i < nodeList.getLength(); i++) 
	    {
	    	Node chldNode = nodeList.item(i);
	    	if (chldNode.getNodeType() == 1)
	    	{
	    		System.out.println("Iter Level: " + iterLevel + ", !!>>!!>>!!>> Child Node is: " + chldNode.getNodeType() + ":" + chldNode.getNodeName());    	
    		
	    		NodeList childrenNodeList = chldNode.getChildNodes();
	    		iterLevel = IaquaXMLReader.crunchMethodNodes(doc, childrenNodeList, ++iterLevel);//, nodeNames);
	    		
	    		if (XMLParser.getNodeNamesTable().containsKey(chldNode.getNodeName()) && XMLParser.getNodeNamesTable().get(chldNode.getNodeName()).compareToIgnoreCase("standard") == 0)
	    		{
	    			try
					{
					  NodeList nList = doc.getElementsByTagName(chldNode.getNodeName()).item(0).getChildNodes();
					  Node nValue = (Node) nList.item(0);
					  System.out.println("For node name " + chldNode.getNodeName() + ", Method Signature: " + nValue.getNodeValue());
					  
					  MethodSignature methodSignature = new MethodSignature();
					  
					  //In outer loop, tokenize on whitespace; This will provide return type, argument type(s) and method name tokens
					  StringTokenizer strToken1 = new StringTokenizer(nValue.getNodeValue(), new String(" "));
					  while (strToken1.hasMoreTokens() == true)
					  {
						  String tokenStr = strToken1.nextToken().trim().replaceAll("^\"|\"$", ""); 
						  
						  StringTokenizer strToken2 = new StringTokenizer(tokenStr, new String("="));
					  	  strToken2.nextToken();
					  	     
					  	  if (tokenStr.startsWith("returntype="))
			  	    	  {
			  	    		    if(strToken2.hasMoreTokens() == true)
			  	                {
			  	    		      methodSignature.returnType = strToken2.nextToken().trim().replaceAll("^\"|\"$", "");
			  	    			  System.out.println("Method Return Type is: " + methodSignature.returnType);
			  	                }
			  	    	  }
					  	  else
					  	  if (tokenStr.startsWith("argtypes="))
				  	      {
				  	    		if(strToken2.hasMoreTokens() == true)
				  	            {
				  	    		  tokenStr = strToken2.nextToken().trim().replaceAll("^\"|\"$", "");
				  	    		  //System.out.println("Argument string: " + tokenStr);
				  	    		  StringTokenizer strToken3 = new StringTokenizer(tokenStr, new String("|"));
				  	    		  //int argid = 0;
				  	    		  Vector<String> args = new Vector<String>();
				  	    		  while (strToken3.hasMoreTokens() == true)
								  {
				  	    			args.add(strToken3.nextToken().trim().replaceAll("^\"|\"$", ""));
				  	    			//System.out.println("Argument #" + argid + ": " + strToken3.nextToken().trim().replaceAll("^\"|\"$", ""));
				  	    			//argid++;
								  }
				  	    		  methodSignature.argTypes = new String[args.size()];
				  	    		  //methodSignature.argTypes = (String[])args.toArray();
				  	    		  Object[] objs = args.toArray();
				  	    		  for(int k = 0; k < objs.length; k++)
				  	    		  {
				  	    			methodSignature.argTypes[k] = (String)objs[k];
				  	    		  }
				  	            }
				  	      }
					  	  else
					  	  {
					  		methodSignature.methodName = tokenStr.trim().replaceAll("^\"|\"$", "");
					  		System.out.println("Method Name: " + methodSignature.methodName);
					  	  }
					  }		
					  
					  /*for(int j = 0; j < methodSignature.argTypes.length; j++)
					  {
						  System.out.println("ArgTypes>>>: " + methodSignature.argTypes[j]);
					  }*/
					  
					  IaquaXMLReader.tableOfMethodSignatures.put(chldNode.getNodeName(), methodSignature);
					  
					}
					catch (Exception e)
		            {
		              System.err.println(e);
		            }	
	    		}
	    	}
	    }
   
	    return --iterLevel;
	 
 }

 //This will load methods from method xml and map them to "standard" constituent parts, attributes and properties of the Iaqua entity in question (see Vector of Nodes in Hierarchy)
 public static void processMethodsFromXML()
 {

	  try 
	  {    
		 //Process XML for the Iaqua method xml
	     File file = new File("C://Users/jonmejoy/Downloads/Iaqua-development/iaquamethods.xml");
	   
	     if (file.exists())
	     {   
		   DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		   DocumentBuilder db = dbf.newDocumentBuilder();
		   Document doc = db.parse(file);
		   doc.getDocumentElement().normalize();

		   System.out.println("Root element: " + doc.getDocumentElement().getNodeName());
		   
		   NodeList nodeLst = doc.getElementsByTagName("cable");
		   System.out.println("nodeLst.getLength(): " + nodeLst.getLength());
		   
		    for (int s = 0; s < nodeLst.getLength(); s++) 
		    {    	   	
			    Node node = nodeLst.item(s);
			    //retain sysout
			    System.out.println("**********************************************Processing Node Type: " + node.getNodeName());
		    	
			    NamedNodeMap nnMap = node.getAttributes();
			    
			    if (nnMap != null)
				{
			    	System.out.println("nnMap.getLength(): " + nnMap.getLength());
			    	
			    	for (int i = 0; i < nnMap.getLength(); i++)
			    	{
			    		System.out.println("(nnMap.item(i).getNodeName(): " + nnMap.item(i).getNodeName());
			    		if (nnMap.item(i).getNodeName().compareToIgnoreCase("cableid") == 0)
			    		{
			    			System.out.println("!!>>!!>>!!>> Cable id is: " + nnMap.item(i).getNodeValue());
			    		}
			    	}   
				}
			    
			    NodeList cableChildrenNodeList = node.getChildNodes();
			    
			    IaquaXMLReader.crunchMethodNodes(doc, cableChildrenNodeList, 1);//, new Vector<String>());
			  }
	   }
	  } 
	  catch (Exception e) 
	  {
	    e.printStackTrace();
	  }
	  
	  //All's well. Indicate parsing success
	  //SchemaManager.parsingErrored = false;
	  //schemaManager.setParsingErrorred(false);
	  return;

 }
 
 private IaquaXMLReader()
 {
 }
}