package org.ossnext.iaqua.client;

import java.util.Iterator;
import java.util.Map;

import org.ossnext.iaqua.ws.IaquaRESTWSProxy;
import org.ossnext.iaqua.xmlhelper.IaquaXMLReader;
import org.ossnext.iaqua.xmlhelper.MethodSignature;
import org.ossnext.iaqua.xmlhelper.XMLParser;

/* IaquaClient.java
 * Created December 09 2012
 * 
 * Copyright (c) 2012, Tellurion OSS Pvt. Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /*
  * @author admin@ossnext.org
  * 
  */

/**
 * Enter description here.
 *
 * @author <a href="mailto:admin@ossnext.org">OSSnext dot org</a>
 * @version : 2.3 $
 *          <p/>
 *          <p><b>Revisions:</b>
 *          <p/>
 *          <p><b>December 09, 2012 ossnext:</b>
 *          <ul>
 *          <li> Copyright (c) 2012 Tellurion OSS Pvt. Ltd. All Rights Reserved.
 *          </ul>
 */

public class IaquaClient 
{
   public static void main(String args[])
   {
	      String[]  paramNames;
	      String[][] paramValues;
		  Iterator<Map.Entry<String, MethodSignature>> it;
		  IaquaRESTWSProxy iaquaRESTWS = new IaquaRESTWSProxy();
		  	
		  IaquaXMLReader.doProcess(null);
		  it = IaquaXMLReader.tableOfMethodSignatures.entrySet().iterator();
			
		  while(it.hasNext())
		  {
		    	Map.Entry<String, MethodSignature> entry = it.next();
		    	
		    	if (entry.getKey() != null) 
		    	{
		          System.out.print(entry.getKey() + " : ");
		          //retStr = entry.getKey() + " | " + retStr;
		        
		          MethodSignature methodSig = entry.getValue();
		          
		          System.out.println("**************************************************************Inspecting methods...");
		          
		          String IaquaDataTypeClassifier = XMLParser.tableOfNodeNames.get(methodSig.getReturnType());
		          
		          //at this time, methods with return type corresponding only to "standard" attribute(s), constituent part(s) and property/ies of an entity is/are valid/supported 
		          if (IaquaDataTypeClassifier != null && IaquaDataTypeClassifier.compareToIgnoreCase("standard") == 0)
		          {
		        	  System.out.println("**************************************************************Standard Method " + methodSig.getMethodName() + " found.");
		        	  
		        	  //To demonstrate how the client should use the WS, we run test case only for the "getWireJacket" method
		        	  //return type for this method is "jacket"
		        	  if(methodSig.getReturnType().compareToIgnoreCase("jacket") == 0)
	        		  {
		        	  
		        	  //if method has a list of arguments
		        	  if (methodSig.getArgTypes().length > 0)
			          {
		        		  String[] argsToRESTWS = new String[methodSig.getArgTypes().length];
		        		  
			        	  paramNames =
			        	            new String[] 
			        	            {
			        	               "Action",
			        	               "Operation",
			        	               "Params"
			        	            };
			        	  
			        	  //Now convert Iaqua data types to Java data types before making call to WS via Java client layer
			        	  for (int ctr = 0; ctr < methodSig.getArgTypes().length; ctr++)
			        	  {
			        		  switch(methodSig.getArgTypes()[ctr])
			        		  {
			        		    case "cableidtype":
			        		    	argsToRESTWS[ctr] = new String("00000028");
			        		    	break;
			        		    	
			        		    case "wireidtype":
			        		    	argsToRESTWS[ctr] = "1";
			        		    	break;
			        		    	
			        		    //default:
			        		    //	argTypes[ctr] = "java.lang.String";
			        		    	
			        		  }
			        	  }
			        	  
			        	  paramValues =
						           new String[][] 
						           {
						             new String[] { "iaquaejb/iaqua-ejb/1.0/ejb?J2EEServer=geronimo,Name=CableResource,Type=IaquaService" },
						             new String[] { methodSig.getMethodName() },
						             argsToRESTWS
						           };
			        	  
			          }
			          else
			        	  //if method has no argument
			          {
			        	  paramNames =
						           new String[] 
						           {
						              "Action",
						              "Operation"
						           };
			        	  
			        	  paramValues =
						           new String[][] 
						           {
						             new String[] { "iaquaejb/iaqua-ejb/1.0/ejb?J2EEServer=geronimo,Name=CableResource,Type=IaquaService" },
						             new String[] { methodSig.getMethodName() }
						           };
			          }
			          
			          /*Calling Java proxy for RESTful WS method here***/
		        	  try
		        	  {
		        		  //Object retObj = iaquaRESTWS.invokeRESTMethod("user1", paramNames, paramValues);
		        		  System.out.println("Invoking REST WS Method: " + methodSig.getReturnType() + " ...");
		        		  Object retObj = iaquaRESTWS.invokeRESTMethod("user1", paramNames, paramValues);
		        		  System.out.println("REST WS Method '" + methodSig.getMethodName() + "' returned result: " + (Integer)retObj);	        		    			        		  
		        	  }
		        	  catch(Exception ex)
		        	  {
		        		  ex.printStackTrace();
		        		  break;
		        	  }
	        		}
		        	else
		        	{
		        		System.out.println("Skipping test case for REST method: " + methodSig.getMethodName() + " ...");
		        	}
		          }
		   }
		}
   }
}
