/**
 * IaquaRESTWSService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.ossnext.iaqua.ws;

public interface IaquaRESTWSService extends javax.xml.rpc.Service {
    public java.lang.String getIaquaRESTWSPortAddress();

    public org.ossnext.iaqua.ws.IaquaRESTWS getIaquaRESTWSPort() throws javax.xml.rpc.ServiceException;

    public org.ossnext.iaqua.ws.IaquaRESTWS getIaquaRESTWSPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
