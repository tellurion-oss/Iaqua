/**
 * IaquaRESTWSServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.ossnext.iaqua.ws;

public class IaquaRESTWSServiceLocator extends org.apache.axis.client.Service implements org.ossnext.iaqua.ws.IaquaRESTWSService {

    public IaquaRESTWSServiceLocator() {
    }


    public IaquaRESTWSServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public IaquaRESTWSServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for IaquaRESTWSPort
    private java.lang.String IaquaRESTWSPort_address = "http://localhost:8080/IaquaWAR/accessRESTWS";

    public java.lang.String getIaquaRESTWSPortAddress() {
        return IaquaRESTWSPort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String IaquaRESTWSPortWSDDServiceName = "IaquaRESTWSPort";

    public java.lang.String getIaquaRESTWSPortWSDDServiceName() {
        return IaquaRESTWSPortWSDDServiceName;
    }

    public void setIaquaRESTWSPortWSDDServiceName(java.lang.String name) {
        IaquaRESTWSPortWSDDServiceName = name;
    }

    public org.ossnext.iaqua.ws.IaquaRESTWS getIaquaRESTWSPort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(IaquaRESTWSPort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getIaquaRESTWSPort(endpoint);
    }

    public org.ossnext.iaqua.ws.IaquaRESTWS getIaquaRESTWSPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            org.ossnext.iaqua.ws.IaquaRESTWSPortBindingStub _stub = new org.ossnext.iaqua.ws.IaquaRESTWSPortBindingStub(portAddress, this);
            _stub.setPortName(getIaquaRESTWSPortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setIaquaRESTWSPortEndpointAddress(java.lang.String address) {
        IaquaRESTWSPort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (org.ossnext.iaqua.ws.IaquaRESTWS.class.isAssignableFrom(serviceEndpointInterface)) {
                org.ossnext.iaqua.ws.IaquaRESTWSPortBindingStub _stub = new org.ossnext.iaqua.ws.IaquaRESTWSPortBindingStub(new java.net.URL(IaquaRESTWSPort_address), this);
                _stub.setPortName(getIaquaRESTWSPortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("IaquaRESTWSPort".equals(inputPortName)) {
            return getIaquaRESTWSPort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://ws.iaqua.ossnext.org/", "IaquaRESTWSService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://ws.iaqua.ossnext.org/", "IaquaRESTWSPort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("IaquaRESTWSPort".equals(portName)) {
            setIaquaRESTWSPortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
