package org.ossnext.iaqua.ws;

public class IaquaRESTWSProxy implements org.ossnext.iaqua.ws.IaquaRESTWS {
  private String _endpoint = null;
  private org.ossnext.iaqua.ws.IaquaRESTWS iaquaRESTWS = null;
  
  public IaquaRESTWSProxy() {
    _initIaquaRESTWSProxy();
  }
  
  public IaquaRESTWSProxy(String endpoint) {
    _endpoint = endpoint;
    _initIaquaRESTWSProxy();
  }
  
  private void _initIaquaRESTWSProxy() {
    try {
      iaquaRESTWS = (new org.ossnext.iaqua.ws.IaquaRESTWSServiceLocator()).getIaquaRESTWSPort();
      if (iaquaRESTWS != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iaquaRESTWS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iaquaRESTWS)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iaquaRESTWS != null)
      ((javax.xml.rpc.Stub)iaquaRESTWS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public org.ossnext.iaqua.ws.IaquaRESTWS getIaquaRESTWS() {
    if (iaquaRESTWS == null)
      _initIaquaRESTWSProxy();
    return iaquaRESTWS;
  }
  
  public java.lang.Object invokeRESTMethod(java.lang.String arg0, java.lang.String[] arg1, java.lang.String[][] arg2) throws java.rmi.RemoteException{
    if (iaquaRESTWS == null)
      _initIaquaRESTWSProxy();
    return iaquaRESTWS.invokeRESTMethod(arg0, arg1, arg2);
  }
  
  public java.lang.String getVersion() throws java.rmi.RemoteException{
    if (iaquaRESTWS == null)
      _initIaquaRESTWSProxy();
    return iaquaRESTWS.getVersion();
  }
  
  
}