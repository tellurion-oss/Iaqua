package org.ossnext.iaqua.servlet;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.geronimo.gbean.GBeanInfo;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.ossnext.iaqua.apptier.RemoteBusinessInterface;
import org.ossnext.iaqua.bridge.webtier.HTTPRequestResponsePair;
import org.ossnext.iaqua.bridge.webtier.SOARequestHandler;
import org.ossnext.iaqua.bridge.webtier.SOARequestHandlerException;
import org.ossnext.iaqua.businesstier.kernel.common.KernelLifeCycleManager;
import org.ossnext.iaqua.businesstier.kernel.geronimo.GeronimoKernelLifeCycleManager;

/* IaquaRESTWSServlet.java
 * Created December 12 2012
 * 
 * Copyright (c) 2012, Tellurion OSS Pvt. Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /*
  * @author admin@ossnext.org
  * 
  */

/**
 * Enter description here.
 *
 * @author <a href="mailto:admin@ossnext.org">OSSnext dot org</a>
 * @version : 2.3 $
 *          <p/>
 *          <p><b>Revisions:</b>
 *          <p/>
 *          <p><b>December 12, 2012 ossnext:</b>
 *          <ul>
 *          <li> Copyright (c) 2012 Tellurion OSS Pvt. Ltd. All Rights Reserved.
 *          </ul>
 */

/**
 * Servlet implementation class IaquaRESTWSServlet
 */
public class IaquaRESTWSServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	private static GBeanInfo GBEANINFO = null;
	private static Logger log = Logger.getLogger(IaquaRESTWSServlet.class);
	
	@EJB
    RemoteBusinessInterface remoteBusinessIntf;

	private KernelLifeCycleManager kernelManager = null;
	private Object retObj = null;
	
	public void init(ServletConfig servletConfig) throws ServletException
	{
	      super.init(servletConfig);

	      BasicConfigurator.configure();
	      Logger.getRootLogger().setLevel(Level.DEBUG);

	      try
	      {
	        kernelManager = GeronimoKernelLifeCycleManager.getManager();
	      }
	      catch (Exception e)
	      {
	    	  log.debug("Exception while attempting to instantiate Kernel with LifeCycle Manager: " + e.toString());
	    	  throw new ServletException();
	      }
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IaquaRESTWSServlet() 
    {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		log.debug("[Tellurion OSS Iaqua] doGet() called ...");
		
		try
	    {
	    	  SOARequestHandler soaHandler = SOARequestHandler.getHandler();
	    	  HTTPRequestResponsePair actionReqResp = new HTTPRequestResponsePair(request, response);
	         
	    	  this.retObj = soaHandler.dispatch(actionReqResp);
	    	  //response.getWriter().write(remoteBusinessIntf.writeOutputInt(this.retObj));
	    	  
	    	  log.debug("[Tellurion OSS Iaqua] retObj is " + retObj.toString());

	    }
	    catch (SOARequestHandlerException ex)
	    {
	         throw new ServletException(ex);
	    }
	}
	
	protected Object doGetAndReturnVal(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		try
		{
			this.doGet(request, response);
			return this.retObj;
		}
		catch (Exception ex)
		{
			throw ex;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
	}

}
