package org.ossnext.iaqua.servlet;


import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.ejb.EJB;

import org.apache.log4j.Logger;
import org.ossnext.iaqua.apptier.RemoteBusinessInterface;
import org.ossnext.iaqua.bridge.webtier.HTTPRequestResponsePair;
import org.ossnext.iaqua.bridge.webtier.SOARequestHandler;
import org.ossnext.iaqua.bridge.webtier.SOARequestHandlerException;
import org.ossnext.iaqua.ws.IaquaRESTWS;

/* MyIaquaServlet.java
 * Created March 01 2012
 * 
 * Copyright (c) 2012, Tellurion OSS Pvt. Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /*
  * @author admin@ossnext.org
  * 
  */

/**
 * Enter description here.
 *
 * @author <a href="mailto:admin@ossnext.org">OSSnext dot org</a>
 * @version : 2.3 $
 *          <p/>
 *          <p><b>Revisions:</b>
 *          <p/>
 *          <p><b>March 01, 2012 ossnext:</b>
 *          <ul>
 *          <li> Copyright (c) 2012 Tellurion OSS Pvt. Ltd. All Rights Reserved.
 *          </ul>
 */

/**
 * Servlet implementation class MyIAquaServlet
 */
public class MyIAquaServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
	@EJB
    RemoteBusinessInterface remoteBusinessIntf;
	
	private static Logger log = Logger.getLogger(MyIAquaServlet.class);
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyIAquaServlet()
    {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		IaquaRESTWSServletTest fntCntlTest = new IaquaRESTWSServletTest("accessSOA");
		try
		{
		  fntCntlTest.setUp();
		  response.getWriter().write(remoteBusinessIntf.writeOutputInt(fntCntlTest.doGetInt()));
		  fntCntlTest.tearDown();
		  //response.getWriter().write(remoteBusinessIntf.writeOutput("To be implemented"));
		}
		catch (Exception ex)
		{
			Logger log2 = Logger.getLogger(MyIAquaServlet.class);	
			log2.info(ex.toString());
			log2.debug(ex.toString());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
	}
	
	public Object doGetAndReturnResult(final HttpServletRequest req,
	           final HttpServletResponse res) throws ServletException, IOException
	{
	    try
	    {
	        SOARequestHandler soaHandler = SOARequestHandler.getHandler();
	        HTTPRequestResponsePair actionReqResp = new HTTPRequestResponsePair(req, res);

	        Object retObj =
		      soaHandler.dispatch(actionReqResp);

	        log.debug("[Tellurion OSS Iaqua] retObj is " + retObj.toString());
	        return retObj;
	    }

	    catch (SOARequestHandlerException ex)
	    {
	       throw new ServletException(ex);
	    }
	}

}
