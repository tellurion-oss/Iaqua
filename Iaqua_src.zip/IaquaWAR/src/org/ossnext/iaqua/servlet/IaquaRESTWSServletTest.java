package org.ossnext.iaqua.servlet;

import java.util.Vector;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.mockobjects.servlet.MockHttpServletRequest;
import com.mockobjects.servlet.MockHttpServletResponse;
import com.mockobjects.servlet.MockServletConfig;

/* IaquaRESTWSServletTest.java
 * Created March 01 2012
 * 
 * Copyright (c) 2012, Tellurion OSS Pvt. Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /*
  * @author admin@ossnext.org
  * 
  */

/**
 * Enter description here.
 *
 * @author <a href="mailto:admin@ossnext.org">OSSnext dot org</a>
 * @version : 2.3 $
 *          <p/>
 *          <p><b>Revisions:</b>
 *          <p/>
 *          <p><b>March 01, 2012 ossnext:</b>
 *          <ul>
 *          <li> Copyright (c) 2012 Tellurion OSS Pvt. Ltd. All Rights Reserved.
 *          </ul>
 */


public class IaquaRESTWSServletTest extends TestCase
{
	
   public IaquaRESTWSServletTest(String name)
   {
      super(name);
   }

   private MockHttpServletRequest createRequest(String[] parmNames, String[][] parmVals)
   {
      MockHttpServletRequest request = new MockHttpServletRequest();

      Vector<Integer> elements = new Vector<Integer>();
      for (int i = 0; i < parmNames.length; i++)
      {
    	  elements.add(i);
      }
      
      request.setupGetAttrubuteNames(elements);
      
      for (int i = 0; i < parmNames.length; i++)
      {
         request.setupAddParameter(parmNames[i], parmVals[i]);
      }
      
      return request;
   }

   public void setUp() throws Exception
   {
      super.setUp();
   }

   public void tearDown() throws Exception
   {
      super.tearDown();
   }

   public int doGetInt() throws Exception
   {

	      MockServletConfig servletConfig = new MockServletConfig();

	      IaquaRESTWSServlet iaquaRESTWSServlet = new IaquaRESTWSServlet();
	      iaquaRESTWSServlet.init(servletConfig);

	      MockHttpServletRequest request;
	      MockHttpServletResponse response;
	      
	      String[] parmNames;
	      String[][] parmVals;
	      
	      response = new MockHttpServletResponse();
	       
	      parmNames =
	           new String[] {
	              "Action",
	              "Operation"
	           };

	      parmVals =
	           new String[][] {
	              new String[] { "iaquaejb/iaqua-ejb/1.0/ejb?J2EEServer=geronimo,Name=CardResource,Type=IaquaService" },
	              new String[] { "retrieveObject" }
	           };

	      request = this.createRequest(parmNames, parmVals);

	      iaquaRESTWSServlet.doGet(request, response);

	      iaquaRESTWSServlet.destroy();
	      return 1;
   }
   
   public Object doGetWithArgs(String[] parmNames, String[][] parmVals) throws Exception
   {

         MockServletConfig servletConfig = new MockServletConfig();
         Object retObj = null;

         IaquaRESTWSServlet iaquaRESTWSServlet = new IaquaRESTWSServlet();
         iaquaRESTWSServlet.init(servletConfig);

	     MockHttpServletRequest request = this.createRequest(parmNames, parmVals);
	     MockHttpServletResponse response = new MockHttpServletResponse();       

	     retObj = iaquaRESTWSServlet.doGetAndReturnVal(request, response);
	     iaquaRESTWSServlet.destroy();
	     return retObj;
   }
}
