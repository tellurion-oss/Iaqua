package org.ossnext.iaqua.ws;

import java.util.Vector;

import javax.jws.WebService;

import org.apache.log4j.Logger;
import org.ossnext.iaqua.bridge.webtier.HTTPRequestResponsePair;
import org.ossnext.iaqua.bridge.webtier.SOARequestHandler;
import org.ossnext.iaqua.bridge.webtier.SOARequestHandlerException;
import org.ossnext.iaqua.servlet.IaquaRESTWSServletTest;
import org.ossnext.iaqua.servlet.MyIAquaServlet;

import com.mockobjects.servlet.MockHttpServletRequest;
import com.mockobjects.servlet.MockHttpServletResponse;

/* IaquaRESTWS.java
 * Created December 09 2012
 * 
 * Copyright (c) 2012, Tellurion OSS Pvt. Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /*
  * @author admin@ossnext.org
  * 
  */

/**
 * Enter description here.
 *
 * @author <a href="mailto:admin@ossnext.org">OSSnext dot org</a>
 * @version : 2.3 $
 *          <p/>
 *          <p><b>Revisions:</b>
 *          <p/>
 *          <p><b>December 09, 2012 ossnext:</b>
 *          <ul>
 *          <li> Copyright (c) 2012 Tellurion OSS Pvt. Ltd. All Rights Reserved.
 *          </ul>
 */


@WebService()
public class IaquaRESTWS
{
	private static Logger log = Logger.getLogger(IaquaRESTWS.class);
	
	public String getVersion() 
	{
		return "2.2";
	}

	public Object invokeRESTMethod(String user, String[]  parmNames, String[][] parmVals) 
	{
		//String retStr = null;
		Object retObj = null;
		
		/*Call RESTful methods here***/
		
        IaquaRESTWSServletTest restwsServletTest = new IaquaRESTWSServletTest("dynSOA");
		
		 Logger log1 = Logger.getLogger(IaquaRESTWS.class);	
	     log1.debug("dynSOA called web layer (servlet)");
		
		 try
		 {
			 restwsServletTest.setUp();
		     retObj = restwsServletTest.doGetWithArgs(parmNames, parmVals);
		     restwsServletTest.tearDown();
		 }
		 catch(Exception ex)
		 {	
			log.info(ex.toString());
			log.debug(ex.toString());
		 }
	      
        /**End call of RESTful methods**/
		
		return retObj;
	}
}